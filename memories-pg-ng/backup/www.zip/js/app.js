(function(){
	'use strict';
	angular.module('myApp', ['onsen.directives']);
})();
